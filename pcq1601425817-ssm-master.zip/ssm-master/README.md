#ssm

Junit:
1、导入jar包
2、右键需要测试的类新建junit case
3、放到src/teset/java下

MyBatis:
1、Maven导依赖jar包
2、新建mybatis-config.xml配置文件
3、新建Mapper接口以及对应Mapper.xml映射配置文件
4、将新建的Mapper.xml映射文件加入mybatis-config.xml
