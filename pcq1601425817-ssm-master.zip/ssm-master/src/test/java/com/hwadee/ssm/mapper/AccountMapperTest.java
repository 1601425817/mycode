package com.hwadee.ssm.mapper;

import static org.junit.Assert.*;

import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.hwadee.ssm.entity.Account;

public class AccountMapperTest {
	
	private static SqlSessionFactory sqlSessionFactory;
	private SqlSession session;
	private AccountMapper accountMapper;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		String resource = "mybatis-config.xml";
		InputStream inputStream = Resources.getResourceAsStream(resource);
		sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
	}
	
	@Before
	public void before(){
		session = sqlSessionFactory.openSession();
		AccountMapper accountMapper = session.getMapper(AccountMapper.class);
	}
	
	@After
	public void after(){
		session.close();
	}
	

	@Test
	public void testFindById() {
		
		Account account = accountMapper.findById(1);
		
		System.out.println( account );
	}
	


}
