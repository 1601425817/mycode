package com.hwadee.ssm.mapper;

import com.hwadee.ssm.entity.Account;

public interface AccountMapper {
	
	
	Account findById(int id);

}
