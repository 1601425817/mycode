package com.finacialsys.service;

public interface PrivilegeService {

}
