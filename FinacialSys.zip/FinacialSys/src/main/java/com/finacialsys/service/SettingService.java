package com.finacialsys.service;


import com.finacialsys.model.entity.User;

public interface SettingService {

	int updateUser(User user);
	
}
