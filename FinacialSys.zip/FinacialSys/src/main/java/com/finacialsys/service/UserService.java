package com.finacialsys.service;

import com.finacialsys.model.entity.User;

public interface UserService {
	
	User getUserInformation(String userID);

	int updateLevelbyID(String userID, int levelID);
}
